This app tests, what for a framework is on the site. This is the list:

"jQuery":
"React": 
"Vue.js":
"Angular":
"Svelte": 
"Ember.js": 
"Backbone.js":
"Alpine.js": 
"Next.js": 
"Nuxt.js": 
"Meteor": 
"Polymer":
"Vanilla JS":  

Music by glitchart 